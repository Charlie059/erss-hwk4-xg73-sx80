package edu.duke.ece568.message;


/**
 *  Message is an action, either <create> or <transactions>
 *  Used Lombok for auto getter and setter
 */
public interface Message {

}
